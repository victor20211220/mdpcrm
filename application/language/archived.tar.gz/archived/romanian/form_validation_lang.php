<?php

$lang['required']			= "Campul %s este obligatoriu.";
$lang['isset']				= "Câmpul %s trebuie să aibă o valoare.";
$lang['valid_email']		= "Câmpul %s trebuie să conţină o adresă de e-mail validă.";
$lang['valid_emails']		= "Câmpul %s trebuie să conţină toate adresele de e-mail valide.";
$lang['valid_url']			= "Câmpul %s trebuie să conţină un URL valid.";
$lang['valid_ip']			= "Câmpul %s trebuie să conţină o adresă IP validă.";
$lang['min_length']			= "Domeniul %s trebuie să fie cel puţin %s de caractere.";
$lang['max_length']			= "Câmpul %s nu poate depăşi %s de caractere.";
$lang['exact_length']		= "Câmpul %s trebuie să aibă exact %s caractere.";
$lang['alpha']				= "Câmpul %s poate conţine numai caractere alfabetice.";
$lang['alpha_numeric']		= "Câmpul %s poate conţine numai caractere alfanumerice.";
$lang['alpha_dash']			= "Campul %s poate conţine numai caractere alfanumerice, linii de subliniere şi cratime.";
$lang['numeric']			= "Câmpul %s trebuie să conţină numai cifre.";
$lang['is_numeric']			= "Câmpul %s trebuie să conţină numai caractere numerice.";
$lang['integer']			= "Câmpul %s trebuie să conţină un număr întreg.";
$lang['regex_match']		= "Câmpul %s nu este în formatul corect.";
$lang['matches']			= "Câmpul %s nu se potrivește cu câmpul %s.";
$lang['is_unique'] 			= "Câmpul %s trebuie să conţină o valoare unică.";
$lang['is_natural']			= "Câmpul %s trebuie să conţină numai numere pozitive.";
$lang['is_natural_no_zero']	= "Câmpul %s trebuie să conţină un număr mai mare decât zero.";
$lang['decimal']			= "Câmpul %s trebuie să conţină un număr zecimal.";
$lang['less_than']			= "Câmpul %s trebuie să conţină cu un număr mai puţin decât %s.";
$lang['greater_than']		= "Câmpul %s trebuie să conţină cu un număr mai mare decât %s.";


/* End of file form_validation_lang.php */
/* Location: ./system/language/english/form_validation_lang.php */