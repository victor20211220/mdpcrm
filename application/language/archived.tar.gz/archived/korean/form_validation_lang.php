<?php

$lang['required']			= "%s필더는 항목이 필요합니다.";
$lang['isset']				= "%s 필드는 값을가지고 있어야 합니다.";
$lang['valid_email']		= "%s 필드는 이메일 주소를 포함 해야 합니다.";
$lang['valid_emails']		= "%s 필드는 유효한 이메일 주소를 포함 해야 합니다.";
$lang['valid_url']			= "%s 필드는 유효한 URL을 포함 해야 합니다.";
$lang['valid_ip']			= "%s 필드는 유효한 ip 주소를 포함 해야 합니다.";
$lang['min_length']			= "%s 필드는 최소한 이어야 합니다 %s 문자 길이.";
$lang['max_length']			= "%s 필드 %s 문자 길이 초과 할수 없습니다.";
$lang['exact_length']		= "%s 필드는 %s 문자의 길이가 정확해야 합니다.";
$lang['alpha']				= "%s 필드는 오직 알파벳만 포함 할 수 있습니다.";
$lang['alpha_numeric']		= "%s 필드는 오직영어 숫자만 포함할 수 있습니다.";
$lang['alpha_dash']			= "%s 필드 영어,숫자, 문자, _ 및 - 포함할 수 있습니다.";
$lang['numeric']			= "%s 필드에는 숫자만 포함 해야 합니다.";
$lang['is_numeric']			= "%s 필드에는 숫자만 포함 해야 합니다.";
$lang['integer']			= "%s 필드는 정수를 포함 해야 합니다.";
$lang['regex_match']		= "%s 필드 올바른 형식이 아니다.";
$lang['matches']			= "%s 필드는 %s 필드와 일치 하지 않습니다.";
$lang['is_unique'] 			= "%s 필드는 고유 값을 포함 해야 합니다.";
$lang['is_natural']			= "%s 필드는 양수만 포함 해야 합니다.";
$lang['is_natural_no_zero']	= "%s 필드는 0 보다 큰 숫자를 포함 해야 합니다.";
$lang['decimal']			= "%s 필드는 10 진수를 포함 해야 합니다.";
$lang['less_than']			= "%s 필드는 %s 미만 숫자를 포함 해야 합니다.";
$lang['greater_than']		= "%s 필드는 %s 보다 큰 숫자를 포함 해야 합니다.";


/* End of file form_validation_lang.php */
/* Location: ./system/language/english/form_validation_lang.php */